package com.cg.testcase;
import java.io.File;
import java.io.FileInputStream;

import org.openqa.selenium.support.PageFactory;

import com.cg.hash.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import jxl.read.biff.BiffException;

import org.junit.*;

import static org.junit.Assert.*;

//import org.openqa.selenium.WebElement;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.Page;
public class hashexcel {
	 static WebDriver driver= new FirefoxDriver();
	 static Page p=new Page();
	 static {
		 PageFactory.initElements(driver, Page.class);
	 }
@BeforeTest
public  void bfr()
{
	//Page p=new Page();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://demo.opencart.com");
		//driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a")).click();
		//driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
	
		p.myaccount.click();
		p.login.click();
		
}	
	@Test(priority=1)
	  public void Test1() throws InterruptedException, IOException {
				String usid[]=excelhash.ece("UserName");
				String pswrd[]=excelhash.ece("Password");		
				
		for(int i=0;i<=3;i++)
		{
			p.uid.clear();
			p.pwd.clear();
			p.uid.sendKeys(usid[i]);
			p.pwd.sendKeys(pswrd[i]);
			p.lgnbtn.click();
		}
		p.searchpro();
		
		String str=p.macbook.getText();
		System.out.println(str);
		assertEquals(str,"MacBook");	
	  }
	
	@Test(priority=2)
	public void test3() throws InterruptedException
	{
		p.wish();
		Thread.sleep(1000);
		
		try
		{
			assertEquals(p.wishmsg.toString(),"Success: You have added MacBook to your wish list!\n x");
		}
		catch(Error e)
		{
			
		}
		
	}
	
	@Test(priority=3)
	public void test2() throws InterruptedException, BiffException, IOException
	{
		p.add();
		Thread.sleep(1000);
		try
		{
			assertEquals(p.addmsg.toString(),"Success: You have added MacBook to your shopping cart!\n x");
		}
		catch(Error e)
		{
			
		}
	}
	
	
	
}
